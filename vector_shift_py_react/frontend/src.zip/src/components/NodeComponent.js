// components/NodeComponent.js
import React, { useState } from 'react';
import '../styles/NodeComponent.css';

const NodeComponent = ({ 
  node, 
  isSelected, 
  isEditing, 
  onSelect, 
  onUpdate, 
  onDelete 
}) => {
  const [isDragging, setIsDragging] = useState(false);
  const [dragOffset, setDragOffset] = useState({ x: 0, y: 0 });

  const handleMouseDown = (e) => {
    if (!isEditing) return;
    
    if (e.button === 0) { // Left click
      setIsDragging(true);
      const rect = e.currentTarget.getBoundingClientRect();
      setDragOffset({
        x: e.clientX - rect.left,
        y: e.clientY - rect.top
      });
      e.stopPropagation();
    }
  };

  const handleMouseMove = (e) => {
    if (isDragging && isEditing) {
      const newX = e.clientX - dragOffset.x;
      const newY = e.clientY - dragOffset.y;
      
      onUpdate(node.id, { 
        position: { x: newX, y: newY } 
      });
    }
  };

  const handleMouseUp = () => {
    setIsDragging(false);
  };

  const handleClick = (e) => {
    onSelect(node);
    e.stopPropagation();
  };

  const handleDelete = () => {
    if (window.confirm(`Delete ${node.name}?`)) {
      onDelete(node.id);
    }
  };

  return (
    <div
      className={`node ${isSelected ? 'selected' : ''} ${isDragging ? 'dragging' : ''}`}
      style={{
        left: `${node.position.x}px`,
        top: `${node.position.y}px`,
        borderColor: node.color,
        backgroundColor: `${node.color}10`
      }}
      onClick={handleClick}
      onMouseDown={handleMouseDown}
      onMouseMove={handleMouseMove}
      onMouseUp={handleMouseUp}
      onMouseLeave={handleMouseUp}
    >
      {/* Node Header */}
      <div 
        className="node-header"
        style={{ backgroundColor: node.color }}
      >
        <div className="node-header-left">
          <span className="node-icon">{node.icon}</span>
          <span className="node-title">{node.name}</span>
        </div>
        {isEditing && (
          <div className="node-header-right">
            <button 
              className="node-delete-btn"
              onClick={handleDelete}
            >
              ×
            </button>
          </div>
        )}
      </div>

      {/* Node Content */}
      <div className="node-content">
        {node.config && (
          <div className="node-config">
            {node.type === 'input' && (
              <>
                <div className="config-field">
                  <label>Type</label>
                  <div className="config-value">{node.config.inputType}</div>
                </div>
                <div className="config-field">
                  <label>Output Fields</label>
                  <div className="config-values">
                    {node.config.outputFields?.map((field, idx) => (
                      <div key={idx} className="config-item">{field}</div>
                    ))}
                  </div>
                </div>
                <div className="config-field">
                  <label>Outputs</label>
                  <div className="config-values">
                    {node.config.outputs?.map((output, idx) => (
                      <div key={idx} className="config-item">{output}</div>
                    ))}
                  </div>
                </div>
              </>
            )}

            {node.type === 'knowledgeBaseReader' && (
              <>
                <div className="config-field">
                  <label>Knowledge Base</label>
                  <div className="config-value">{node.config.knowledgeBase || 'Not selected'}</div>
                </div>
                <div className="config-field">
                  <label>Search Query</label>
                  <div className="config-value">{node.config.searchQuery}</div>
                </div>
                <div className="config-field">
                  <label>Language</label>
                  <div className="config-value">{node.config.language}</div>
                </div>
                <div className="config-field">
                  <label>Output Fields</label>
                  <div className="config-values">
                    {node.config.outputFields?.map((field, idx) => (
                      <div key={idx} className="config-item">{field}</div>
                    ))}
                  </div>
                </div>
              </>
            )}
          </div>
        )}

        {/* Connection Handles */}
        <div className="node-handles">
          <div className="handle handle-input"></div>
          <div className="handle handle-output"></div>
        </div>
      </div>
    </div>
  );
};

export default NodeComponent;