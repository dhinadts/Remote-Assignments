// components/NodePanel.js
import React from 'react';
import '../styles/Nodepanel.css';

const NodePanel = ({ nodeTypes = [], onAddNode, activeCategory }) => {
  const handleDragStart = (e, nodeType) => {
    e.dataTransfer.setData('node-type', nodeType);
    e.dataTransfer.effectAllowed = 'copy';
  };

  const handleClick = (nodeType) => {
    if (onAddNode) {
      onAddNode(nodeType);
    }
  };

  return (
    <div className="node-panel">
      <div className="node-panel-header">
        <h3>{activeCategory} Nodes</h3>
        <span className="node-count">{nodeTypes.length} nodes</span>
      </div>
      
      <div className="node-palette">
        {nodeTypes.length === 0 ? (
          <div className="no-nodes">
            <p>No nodes available for this category</p>
          </div>
        ) : (
          nodeTypes.map((node) => (
            <div
              key={node.type}
              className="node-item"
              draggable={true}
              onDragStart={(e) => handleDragStart(e, node.type)}
              onClick={() => handleClick(node.type)}
              title={`Add ${node.name} node`}
            >
              <div className="node-icon" style={{ backgroundColor: node.color + '20' }}>
                <span style={{ color: node.color, fontSize: '20px' }}>
                  {node.icon}
                </span>
              </div>
              <div className="node-info">
                <h4 className="node-name">{node.name}</h4>
                <p className="node-description">{node.description}</p>
              </div>
            </div>
          ))
        )}
      </div>
      
      <div className="node-panel-footer">
        <p className="drag-hint">💡 Drag nodes onto the canvas or click to add</p>
      </div>
    </div>
  );
};

export default NodePanel;