// components/PipelineCanvas.js - Corrected Version
import React, { useRef, useState } from 'react';
import NodeComponent from './NodeComponent';
import '../styles/PipelineCanvas.css';  // Make sure this CSS file exists

const PipelineCanvas = ({ 
  nodes = [],  // Added default value
  connections = [], 
  onNodeSelect, 
  onNodeUpdate, 
  onNodeDelete, 
  onAddNode,
  selectedNode,
  isEditing
}) => {
  const canvasRef = useRef(null);
  const [isDragging, setIsDragging] = useState(false);
  const [dragStart, setDragStart] = useState({ x: 0, y: 0 });
  const [viewportOffset, setViewportOffset] = useState({ x: 0, y: 0 });

  const handleCanvasClick = (e) => {
    if (e.target === canvasRef.current) {
      onNodeSelect(null);
    }
  };

  const handleDragOver = (e) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';
  };

  const handleDrop = (e) => {
    e.preventDefault();
    const type = e.dataTransfer.getData('node-type');
    if (type && onAddNode) {
      const rect = canvasRef.current.getBoundingClientRect();
      const x = e.clientX - rect.left - viewportOffset.x;
      const y = e.clientY - rect.top - viewportOffset.y;
      onAddNode(type, { x, y });
    }
  };

  const handleMouseDown = (e) => {
    if ((e.button === 1 || (e.button === 0 && e.shiftKey)) && isEditing) {
      setIsDragging(true);
      setDragStart({ x: e.clientX, y: e.clientY });
      e.preventDefault();
    }
  };

  const handleMouseMove = (e) => {
    if (isDragging && canvasRef.current) {
      const deltaX = e.clientX - dragStart.x;
      const deltaY = e.clientY - dragStart.y;
      
      setViewportOffset(prev => ({
        x: prev.x + deltaX,
        y: prev.y + deltaY
      }));
      
      setDragStart({ x: e.clientX, y: e.clientY });
    }
  };

  const handleMouseUp = () => {
    setIsDragging(false);
  };

  // Calculate connection lines
  const connectionLines = connections.map((conn, index) => {
    const fromNode = nodes.find(n => n.id === conn.from);
    const toNode = nodes.find(n => n.id === conn.to);
    
    if (!fromNode || !toNode) return null;
    
    const fromX = fromNode.position.x + 100; // Node width/2
    const fromY = fromNode.position.y + 30;  // Node height/2
    const toX = toNode.position.x + 100;
    const toY = toNode.position.y + 30;
    
    const length = Math.sqrt(Math.pow(toX - fromX, 2) + Math.pow(toY - fromY, 2));
    const angle = Math.atan2(toY - fromY, toX - fromX);
    
    return {
      id: `conn_${index}`,
      style: {
        position: 'absolute',
        left: `${fromX}px`,
        top: `${fromY}px`,
        width: `${length}px`,
        transform: `rotate(${angle}rad)`,
        transformOrigin: '0 0',
        height: '2px',
        backgroundColor: '#4f46e5',
        zIndex: 1
      }
    };
  }).filter(Boolean);

  return (
    <div 
      ref={canvasRef}
      className={`pipeline-canvas ${isDragging ? 'dragging' : ''} ${isEditing ? 'editing' : ''}`}
      onClick={handleCanvasClick}
      onDragOver={handleDragOver}
      onDrop={handleDrop}
      onMouseDown={handleMouseDown}
      onMouseMove={handleMouseMove}
      onMouseUp={handleMouseUp}
      onMouseLeave={handleMouseUp}
      style={{
        position: 'relative',
        transform: `translate(${viewportOffset.x}px, ${viewportOffset.y}px)`,
        transition: isDragging ? 'none' : 'transform 0.1s ease'
      }}
    >
      {/* Grid Overlay */}
      <div className="grid-overlay"></div>

      {/* Connection Lines */}
      {connectionLines.map(conn => (
        <div 
          key={conn.id}
          className="connection-line"
          style={conn.style}
        />
      ))}

      {/* Nodes */}
      {nodes.map(node => (
        <NodeComponent
          key={node.id}
          node={node}
          isSelected={selectedNode?.id === node.id}
          isEditing={isEditing}
          onSelect={onNodeSelect}
          onUpdate={onNodeUpdate}
          onDelete={onNodeDelete}
          viewportOffset={viewportOffset}
        />
      ))}

      {/* Drop Zone Overlay */}
      <div className="drop-zone">
        <p>Drag and drop nodes here</p>
      </div>
    </div>
  );
};

export default PipelineCanvas;